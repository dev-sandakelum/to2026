<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>[ Portfolio ] — Note</title>
  <link rel="stylesheet" href="css/styles.css" />
</head>
<body class="page-note">

<nav class="navbar">
  <div class="nav-logo">[ Logo ]</div>
  <ul class="nav-links">
    <li><a href="index.php">Home</a></li>
    <li><a href="works.php">Works</a></li>
    <li><a href="apps.php">Apps</a></li>
    <li><a href="notes.php" class="active">Notes</a></li>
    <li><a href="quiz.php">Quiz</a></li>
    <li><a href="blog.php">Blog</a></li>
    <li><a href="working.php">Working</a></li>
  </ul>
  <div class="nav-right" data-modal-open="modal-profile">[ Profile ]</div>
  <button class="nav-toggle" aria-label="Open menu"><span></span><span></span><span></span></button>
</nav>

<!-- Mobile Drawer -->
<div class="nav-drawer">
  <div class="nav-drawer-overlay"></div>
  <div class="nav-drawer-panel">
    <div class="nav-drawer-header">
      <div class="nav-drawer-logo">[ Logo ]</div>
      <button class="nav-drawer-close" aria-label="Close menu">✕</button>
    </div>
    <nav class="nav-drawer-links">
      <a href="index.php">Home</a>
      <a href="works.php">Works</a>
      <a href="apps.php">Apps</a>
      <a href="notes.php" class="active">Notes</a>
      <a href="quiz.php">Quiz</a>
      <a href="blog.php">Blog</a>
      <a href="working.php">Working</a>
    </nav>
    <div class="nav-drawer-footer">
      <button class="nav-drawer-profile" data-modal-open="modal-profile">[ Profile / Admin ]</button>
    </div>
  </div>
</div>

<main>
  <div class="note-layout">

    <!-- Desktop Sidebar TOC -->
    <aside class="note-sidebar">
      <h4>[ Contents ]</h4>
      <a href="#sec1">[ Section 1 ]</a>
      <a href="#sec2">[ Section 2 ]</a>
      <a href="#sec3">[ Section 3 ]</a>
      <a href="#sec4">[ Section 4 ]</a>
      <a href="#sec5">[ Section 5 ]</a>
      <div style="margin-top:16px;">
        <a href="notes.php"><button class="btn sm" style="width:100%;">← [ Back ]</button></a>
      </div>
    </aside>

    <!-- Content -->
    <div class="note-content">
      <div class="section">
        <div class="section-title">Note</div>
        <h2>[ Note Title ]</h2>
        <div class="card-tags" style="margin-bottom:16px;"><span class="tag">[ Tag 1 ]</span><span class="tag">[ Tag 2 ]</span></div>

        <div class="content-block" id="sec1">
          <h3>[ Section 1 Heading ]</h3>
          <p>[ Section 1 content placeholder. This is where the note body text goes. Multiple paragraphs of content describing the topic in detail. ]</p>
        </div>

        <div class="content-block" id="sec2">
          <h3>[ Section 2 Heading ]</h3>
          <p>[ Section 2 content placeholder. More detailed information about this subtopic. Can include lists, code snippets, or other content. ]</p>
        </div>

        <div class="content-block" id="sec3">
          <h3>[ Section 3 Heading ]</h3>
          <p>[ Section 3 content placeholder. Continuing the note with additional context and information. ]</p>
        </div>

        <div class="content-block" id="sec4">
          <h3>[ Section 4 Heading ]</h3>
          <p>[ Section 4 content placeholder. Final thoughts, summary, or additional resources. ]</p>
        </div>

        <div class="content-block" id="sec5">
          <h3>[ Section 5 Heading ]</h3>
          <p>[ Section 5 content placeholder. Additional notes, references, or supplementary material. ]</p>
        </div>
      </div>
    </div>

  </div>
</main>

<!-- Mobile TOC Drawer (right side) -->
<div class="toc-drawer" id="toc-drawer">
  <div class="toc-drawer-overlay" id="toc-overlay"></div>
  <div class="toc-drawer-panel">
    <div class="toc-drawer-header">
      <span class="toc-drawer-title">[ Contents ]</span>
      <button class="toc-drawer-close" id="toc-close" aria-label="Close contents">✕</button>
    </div>
    <nav class="toc-drawer-links">
      <a href="#sec1">[ Section 1 ]</a>
      <a href="#sec2">[ Section 2 ]</a>
      <a href="#sec3">[ Section 3 ]</a>
      <a href="#sec4">[ Section 4 ]</a>
      <a href="#sec5">[ Section 5 ]</a>
    </nav>
    <div class="toc-drawer-footer">
      <a href="notes.php"><button class="btn sm" style="width:100%;">← [ Back to Notes ]</button></a>
    </div>
  </div>
</div>

<!-- Floating TOC trigger (mobile only) -->
<button class="toc-fab" id="toc-fab" aria-label="Open contents">
  <span class="toc-fab-icon">☰</span>
  <span class="toc-fab-label">[ Contents ]</span>
</button>

<div class="modal-overlay" id="modal-profile">
  <div class="modal-box">
    <div class="modal-header"><strong>[ Profile ]</strong><button class="modal-close">✕</button></div>
    <p style="font-size:13px;color:var(--text-muted);margin-bottom:12px;">[ User profile placeholder. ]</p>
    <a href="admin.php"><button class="btn sm">[ Admin Panel ]</button></a>
  </div>
</div>

<footer>
  <div class="footer-grid">
    <div class="footer-col"><h4>[ Brand ]</h4><a href="#">[ About ]</a><a href="#">[ Contact ]</a></div>
    <div class="footer-col"><h4>[ Work ]</h4><a href="works.php">[ Works ]</a><a href="apps.php">[ Apps ]</a></div>
    <div class="footer-col"><h4>[ Content ]</h4><a href="notes.php">[ Notes ]</a><a href="blog.php">[ Blog ]</a></div>
    <div class="footer-col"><h4>[ Other ]</h4><a href="quiz.php">[ Quiz ]</a><a href="working.php">[ Working ]</a></div>
  </div>
  <div class="footer-bottom">[ Footer text · © 2024 · All rights reserved ]</div>
</footer>

<script src="js/main.js"></script>
<script>
  const tocDrawer  = document.getElementById('toc-drawer');
  const tocOverlay = document.getElementById('toc-overlay');
  const tocClose   = document.getElementById('toc-close');
  const tocFab     = document.getElementById('toc-fab');

  function openToc() {
    tocDrawer.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeToc() {
    tocDrawer.classList.remove('open');
    document.body.style.overflow = '';
  }

  tocFab.addEventListener('click', openToc);
  tocClose.addEventListener('click', closeToc);
  tocOverlay.addEventListener('click', closeToc);

  // close on link tap so user lands on section
  document.querySelectorAll('.toc-drawer-links a').forEach(a => {
    a.addEventListener('click', closeToc);
  });
</script>
</body>
</html>

